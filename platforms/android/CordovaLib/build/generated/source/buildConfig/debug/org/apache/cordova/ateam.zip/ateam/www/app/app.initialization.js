(function(angular) {
	angular.module('ateam').run(runBlock);
	
	runBlock.$inject = ['settingsService', 'databaseService'];
	function runBlock(settingsService, databaseService) {
//		settingsService.initializeSettings();
//		databaseService.initializeDatabase();
	};
})(angular);