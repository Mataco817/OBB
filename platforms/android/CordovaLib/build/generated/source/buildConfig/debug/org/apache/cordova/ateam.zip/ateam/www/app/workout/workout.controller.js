(function(angular) {
	angular
		.module('workout')
		.controller('WorkoutController', WorkoutController);
	
	WorkoutController.$inject = ['$scope', '$timeout', '$mdDialog'];
	function WorkoutController($scope, $timeout, $mdDialog) {
		var vm = this;
	};
})(angular);