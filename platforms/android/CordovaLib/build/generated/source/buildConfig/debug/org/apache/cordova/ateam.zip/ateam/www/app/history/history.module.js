(function(angular){
	angular.module('history', []);
})(angular);