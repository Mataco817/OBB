(function(angular){
	angular.module('settings', []);
})(angular);