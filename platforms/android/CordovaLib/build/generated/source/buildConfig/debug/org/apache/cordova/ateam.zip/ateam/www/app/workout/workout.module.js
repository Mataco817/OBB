(function(angular){
	angular.module('workout', []);
})(angular);