(function(angular){
	angular.module('shell', []);
})(angular);