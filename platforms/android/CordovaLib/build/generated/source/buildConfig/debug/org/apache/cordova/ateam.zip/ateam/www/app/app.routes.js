/*
 * This is for setting up the routing for the application
 */
(function(angular){
	angular.module('appRoutes', ['ui.router'])
	
	.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
		$stateProvider
		.state('home', {
			abstact: true,
		    url: '/home',
			templateUrl: 'app/shell/home.html',
		    controller: 'HomeController',
		    controllerAs: 'homeCtrl'
		})
		.state('home.login', {
			url: '/login',
			templateUrl: 'app/login/login.html',
		    controller: 'LoginController',
		    controllerAs: 'loginCtrl'
		})
		.state('home.main', {
			url: '/main',
			templateUrl: 'app/workout/tab-workout.html',
	        controller: 'WorkoutController',
	        controllerAs: 'workoutCtrl'
		});

		// if none of the above states are matched, use this as the fallback
		$urlRouterProvider.otherwise('/tab/text1');
	}]);
})(angular);